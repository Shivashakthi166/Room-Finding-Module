// var highlight = document.querySelector(".seatingCont");
