// var name = document.querySelector(".userName");
// var email = document.querySelector(".userEmail");
// var phoneNo = document.querySelector(".userPhoneNo");
// var button = document.querySelector(".button");

// button.addEventListener("click", () => {
//   var obj = {
//     name: name.value,
//     email: email.value,
//     phoneNo: phoneNo.value,
//   };

//   fetch("/login", {
//     method: "POST",
//     headers: {
//       "Content-type": "application/json",
//     },
//     body: JSON.stringify(obj),
//   });
// });
console.log("bhuvan");
